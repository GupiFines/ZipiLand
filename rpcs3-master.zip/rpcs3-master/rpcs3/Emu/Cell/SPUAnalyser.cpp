#include "stdafx.h"
#include "SPUAnalyser.h"
#include "SPUOpcodes.h"

const extern spu_decoder<spu_itype> g_spu_itype{};
const extern spu_decoder<spu_iname> g_spu_iname{};
const extern spu_decoder<spu_iflag> g_spu_iflag{};
